<?php

use Drupal\trash\TrashStorageTrait;

/**
 * Provides a custom storage class for trash-enabled entity types.
 */
class Drupal__node__NodeStorageTrash6853c11d34c6d extends \Drupal\node\NodeStorage {

  use TrashStorageTrait;

}
